﻿using System.Diagnostics;
using System.Text;
using Moq;
using MorseCode.Core.Infrastructure.Logging;
using MorseCode.Core.Services;
using MorseCode.Infrastructure.Logging;
using MorseCode.Services;

namespace MorseCode.Test.Services;

[TestClass]
public class EncodeServiceTest : BaseClass
{
    [TestMethod]
    public void TestHelloWord()
    {
        // Arrange

        const string inputString = "HELLO, WORLD!";
        var inputCharQueue = new Queue<char>(inputString.ToCharArray());
        const string expectedOutput = ".... . .-.. .-.. --- --..--    .-- --- .-. .-.. -.. -.-.-- ";

        // Mock StreamReader
        var mockReader = new Mock<StreamReader>(new MemoryStream());
        var charQueue = new Queue<char>(inputString.ToCharArray());
        mockReader.Setup(r => r.Read(It.IsAny<char[]>(), It.IsAny<int>(), It.IsAny<int>()))
                      .Returns((char[] buffer, int index, int count) =>
                      {
                          int charsToRead = Math.Min(count, charQueue.Count);
                          for (int i = 0; i < charsToRead; i++)
                          {
                              buffer[index + i] = charQueue.Dequeue();
                          }
                          return charsToRead;
                      });

        // Mock StreamWriter
        var outputBuilder = new StringBuilder();
        var mockWriter = new Mock<StreamWriter>(new MemoryStream());
        mockWriter.Setup(w => w.WriteAsync(It.IsAny<string>()))
            .Callback<string>(s => outputBuilder.Append(s))
            .Returns(Task.CompletedTask);

        ILogging logger = new ConsoleLogging();
        IEncodeService service = new EncodeService(logger);

        // Act

        service.Encode(morseCodeJsonString, mockReader.Object, mockWriter.Object, LogLevel.Trace);

        // Assert

        Assert.AreEqual(expectedOutput, outputBuilder.ToString());
    }

    /// <summary>
    /// TestPerformance processes a high volume of data and asserts completion within time limit.
    /// Modified timeLimitInSeconds and testCharacterLimit for greater testing
    /// </summary>
    [TestMethod]
    public void TestPerformance()
    {
        // Arrange

        const int timeLimitInSeconds = 10;
        var stopwatch = new Stopwatch();

        const int testCharacterLimit = 10_000_000;
        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
        var random = new Random();

        // Mock StreamReader
        var readerCharacterCount = 0;
        var mockReader = new Mock<StreamReader>(new MemoryStream());
        mockReader.Setup(r => r.Read(It.IsAny<char[]>(), It.IsAny<int>(), It.IsAny<int>()))
                      .Returns((char[] buffer, int index, int count) =>
                      {
                          int charsToRead = Math.Min(count, testCharacterLimit - readerCharacterCount);
                          for (int i = 0; i < charsToRead; i++)
                          {
                              buffer[index + i] = chars[random.Next(chars.Length)];
                              readerCharacterCount++;
                          }
                          return charsToRead;
                      });

        // Mock StreamWriter
        var outputBuilder = new StringBuilder();
        var mockWriter = new Mock<StreamWriter>(new MemoryStream());

        ILogging logger = new ConsoleLogging();
        IEncodeService service = new EncodeService(logger);

        // Act

        stopwatch.Start();

        service.Encode(morseCodeJsonString, mockReader.Object, mockWriter.Object);

        stopwatch.Stop();
        double elapsedSeconds = stopwatch.Elapsed.TotalSeconds;

        // Assert

        Assert.AreEqual(readerCharacterCount, testCharacterLimit);
        Assert.IsTrue(elapsedSeconds <= timeLimitInSeconds, $"Method exceeded the time limit of {timeLimitInSeconds} seconds. Actual time: {elapsedSeconds} seconds.");
    }
}
